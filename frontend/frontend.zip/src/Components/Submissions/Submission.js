import { useSelector } from "react-redux";
import Main from "../../Containers/Main/Main";

const Submission = () => {

    const { user } = useSelector((state) => state.user);


    return (

        <Main> 


        </Main>
    )


}

export default Submission;